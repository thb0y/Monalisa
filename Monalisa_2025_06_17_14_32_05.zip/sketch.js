function setup() {
  createCanvas(400, 400);
}

function draw() {
  background('#fffeff');
  fill('#EBD6C4');
  strokeWeight(4)
  circle(200,200,300); //rosto
   fill('#DBD4D4');
  circle(150,150,60);  //olho esquerdo
   fill('#0b0b0b');  //olho direito
  circle(250,150,60);
  line(150,270,250,235);  //boca
  fill('#DDC3B5');
  triangle(200,180,170,220,220,220);  //nariz
  line(125,115,180,100);  //sombrancelha esquerda
  line(225,100,275,115,);  //sombrancelha direita
  fill('#70AEB1');
  circle(150,150,45);  //pupila esquerda
   fill('#ffffff');
  circle(250,150,45);  //pupila direita branca
   fill('#0b0b0b');
  circle(250,150,30);  //pupila direita preta
   fill('#ffffff');
  circle(250,150,15);  //pupila direita branca
  fill('#0b0b0b');
   circle(250,150,5);  //pupila direita preta
  
  if(mouseIsPressed){
     console.log(mouseX,mouseY);
      }
}